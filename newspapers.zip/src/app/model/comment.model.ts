export class Comments{
    id;
    pid;
    username;
    com;
    constructor(id,pid,username,com){
        this.id=id;
        this.pid=pid;
        this.username=username;
        this.com=com;
    }
}